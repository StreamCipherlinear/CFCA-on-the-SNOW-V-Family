Conditional Fast Correlation Attack on the SNOW-V Family

=========================================================



Source code accompanying the paper

"Conditional Fast Correlation Attack and Its Application to the

SNOW-V Family".



Repository layout

\-----------------



&#x20; CFCA on SNOW-Vi (SNOW-V)/     -- attack on SNOW-V and SNOW-Vi

&#x20; CFCA on SNOW 5G/              -- attack on SNOW 5G



Each folder contains its own README with detailed instructions.



License

\-------



This code is provided for academic and research purposes.

Please cite the corresponding paper if you use it in your work.

