Mask Search Workflow for SNOW-V / SNOW-Vi
============================================

This document describes the step-by-step procedure used to search for
high-correlation linear masks for SNOW-V and SNOW-Vi in the conditional fast
correlation attack. Each step relies on dedicated C/C++ programs and
produces intermediate files that are consumed by the subsequent steps.

--------------------------------------------------------------------
Step 1 – Selection of the output mask gamma
--------------------------------------------------------------------
Input:
  - "Correlation computation for the N3.cpp"
  - "255 nonzero values of gamma.txt"

Procedure:
  Execute the program to evaluate the upper bound on cor(P3) for every
  candidate gamma. The script enumerates the active-byte space and
  records the corresponding correlations.

Output:
  - Candidates of gamma sorted by cor(P3).

--------------------------------------------------------------------
Step 2 – Evaluation of cor(N1)
--------------------------------------------------------------------
Input:
  - "Correlation computation for the N1.cpp"

Procedure:
  The program exhaustively computes the correlation cor(N1) for all
  non-zero values of beta and m. A lookup table is built for efficient
  later use.

Output:
  - A file containing tuples (beta, m, log2|cor(N1)|) (e.g., c(N1).txt).

--------------------------------------------------------------------
Step 3 – Screening of mask candidates by cor(N1)·cor(N3)
--------------------------------------------------------------------
Input:
  - "Candidates of (n, xi, h, beta, m) by cor(N1)cor(N3).cpp"
  - File from Step 2 (c(N1).txt)

Procedure:
  The program reads the N1 correlations and exhaustively searches over
  combinations of the masks n, xi, h, together with beta and m, to filter
  candidates based on the product cor(N1)·cor(N3). Only combinations
  whose correlation exceeds a predefined threshold are kept.

Output:
  - "0x81ec5a80.txt" – candidate masks for the subsequent N2 evaluation.

--------------------------------------------------------------------
Step 4 – Optimization of (alpha, l) for classical and conditional N2
--------------------------------------------------------------------
Input:
  - "0x81ec5a80.txt" (from Step 3)
  - "Classical_candidates of (alpha, l).cpp"
  - "Computation of conditional correlation.cpp"

Procedure:
  1. Classical correlation:
     For each surviving tuple (h, xi), the program
     "Classical_candidates of (alpha, l).cpp" exhaustively searches all
     non-zero byte pairs (alpha, l) to maximise the contribution of N2.
     The overall classical correlation is then obtained by combining the
     best sub-approximations.

  2. Conditional correlation:
     The program "Computation of conditional correlation.cpp" evaluates
     the conditional correlation cor_con(N2) by, for every possible
     keystream output value z^{(t-1)}, selecting the optimal mask l_z and
     computing the average maximum absolute correlation.

Output:
  The best linear masks (including alpha, l and all previously determined
  masks) together with their correlation exponents. These values are used
  to mount the final fast correlation attack on SNOW-V / SNOW-Vi.

--------------------------------------------------------------------
All programs and data files are available in the repository. Please refer
to the comments inside each source file for implementation details and
parameter settings.