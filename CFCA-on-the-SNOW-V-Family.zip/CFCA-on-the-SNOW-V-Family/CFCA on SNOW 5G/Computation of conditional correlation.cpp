/*
 * Conditional correlation search for N2 .
 *
 * This program reads mask candidates from a file (by default "0x5a80.txt")
 * that were pre‑screened by the N1·N3 stage, and for each candidate it
 * evaluates the conditional correlation contribution of N2.  It works with
 * masks obtained from either cor(N3^H) (upper 16‑bit block) or
 * cor(N1)·cor(N3^L) (lower block) of the SNOW 5G cipher, as well as with
 * the corresponding masks for SNOW‑Vi.
 *
 * For a given fixed output value s (one of the 256 possible keystream
 * bytes), the optimal mask l is chosen to maximise |cor|, and the final
 * figure of merit is the log₂ of the average maximum absolute correlation
 * over all s.  The overall score of a candidate is the sum of the N2
 * exponents over its four active bytes plus the pre‑computed N1·N3 exponent,
 * and the line with the highest score is reported.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdint.h>
#include <math.h>

/* ──────────────────────────── GF(2^8) helpers ──────────────────────────── */

/**
 * Multiplication in GF(2^8) with the AES polynomial x^8+x^4+x^3+x+1.
 */
uint8_t gfmul(uint8_t a, uint8_t b) {
    uint8_t p = 0, hi_bit_set;
    for (int i = 0; i < 8; i++) {
        if (b & 1) p ^= a;
        hi_bit_set = a & 0x80;
        a <<= 1;
        if (hi_bit_set) a ^= 0x1b;
        b >>= 1;
    }
    return p;
}

/**
 * Dot product (= parity of bitwise AND), returns 0 or 1.
 */
uint8_t dot_product(uint8_t a, uint8_t b) {
    uint8_t r = a & b;
    r ^= (r >> 4);
    r ^= (r >> 2);
    r ^= (r >> 1);
    return r & 1;
}

/**
 * For a 32‑bit mask t = (t4,t3,t2,t1) (big‑endian byte order),
 * find the 8‑bit output masks that give perfect correlation (±256)
 * for the four AES S‑box equations (cases 0..3), if they exist.
 * Results are stored in results[0..3]; a zero value indicates none found.
 */
void allbox_optimized(uint32_t t, uint8_t* results) {
    uint8_t t1 = t & 0xFF, t2 = (t >> 8) & 0xFF, t3 = (t >> 16) & 0xFF, t4 = (t >> 24) & 0xFF;
    uint8_t x_times_2[256];
    for (int x = 0; x < 256; x++) x_times_2[x] = gfmul(x, 2);
    uint8_t c1 = t1 ^ t4, c2 = t2 ^ t3 ^ t4, c3 = t1 ^ t2, c4 = t1 ^ t3 ^ t4,
            c5 = t2 ^ t3, c6 = t1 ^ t2 ^ t4, c7 = t3 ^ t4, c8 = t1 ^ t2 ^ t3;
    for (int case_num = 0; case_num < 4; case_num++) {
        results[case_num] = 0;   // default: no valid mask
        for (int i = 0; i < 256; i++) {
            int s = 0;
            for (int x = 0; x < 256; x++) {
                uint8_t cond = 0;
                switch (case_num) {
                    case 0: cond = dot_product(i, x) ^ dot_product(c1, x_times_2[x]) ^ dot_product(c2, x); break;
                    case 1: cond = dot_product(i, x) ^ dot_product(c3, x_times_2[x]) ^ dot_product(c4, x); break;
                    case 2: cond = dot_product(i, x) ^ dot_product(c5, x_times_2[x]) ^ dot_product(c6, x); break;
                    case 3: cond = dot_product(i, x) ^ dot_product(c7, x_times_2[x]) ^ dot_product(c8, x); break;
                }
                if (cond == 0) s++; else s--;
            }
            if (s == 256) { results[case_num] = i; break; }
        }
    }
}

/* ──────────────────── Hexadecimal string conversion ───────────────────── */

uint32_t hex_string_to_uint(const char* hex_str) {
    const char* str = hex_str;
    if (strncmp(str, "0x", 2) == 0 || strncmp(str, "0X", 2) == 0) str += 2;
    uint32_t res = 0;
    while (*str) {
        char c = *str;
        uint8_t v;
        if (c >= '0' && c <= '9') v = c - '0';
        else if (c >= 'a' && c <= 'f') v = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') v = c - 'A' + 10;
        else break;
        res = (res << 4) | v;
        str++;
    }
    return res;
}

/* ─────────────────────── AES S‑box ─────────────────────────────────────── */

static const uint8_t S_BOX[256] = {
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
};

/* ───────── Pre‑computed dot product table (parity of bitwise AND) ──────── */

uint8_t DOT_TABLE[256][256];
int dot_table_computed = 0;

void compute_dot_table() {
    if (dot_table_computed) return;
    for (int i = 0; i < 256; i++)
        for (int j = 0; j < 256; j++) {
            uint8_t r = 0;
            for (int k = 0; k < 8; k++)
                if (((i >> k) & 1) && ((j >> k) & 1)) r ^= 1;
            DOT_TABLE[i][j] = r;
        }
    dot_table_computed = 1;
}

/* ─── Conditional correlation evaluation for one (v1, v2) byte pair ──────── */

/**
 * For a given pair of active bytes (v1 = h_byte, v2 = ξ_byte),
 * this function computes the conditional correlation of N₂.
 *
 * For each possible keystream byte s (0..255), the best mask l is chosen
 * to maximise |cor|, and then the average of these maximal |cor| values
 * over all s is computed.  The return value is log₂(average_max_abs_cor).
 * If the average is (close to) zero, *all_zero is set to 1.
 */
double compute_best_exponent_for_pair(uint8_t v1, uint8_t v2, int* all_zero) {
    compute_dot_table();
    uint8_t table_v1[256], table_v2[256];
    for (int i = 0; i < 256; i++) {
        table_v1[i] = DOT_TABLE[v1][S_BOX[i]];
        table_v2[i] = DOT_TABLE[v2][S_BOX[i]];
    }
    double sum_max_abs = 0.0;
    int found = 0;
    for (int s = 0; s < 256; s++) {
        double max_abs = -1.0;
        for (int l = 0; l < 256; l++) {
            uint64_t total = 0, valid = 0;
            for (int x = 0; x < 256; x++) {
                uint8_t v1_sbox = table_v1[x];
                for (int y = 0; y < 256; y++) {
                    uint8_t z = s ^ ((x + y) & 0xFF);
                    uint8_t v2_sbox = table_v2[z];
                    total++;
                    if ((v1_sbox ^ DOT_TABLE[l][y] ^ v2_sbox) == 0)
                        valid++;
                }
            }
            double corr = (2.0 * valid - total) / total;
            double abs_corr = fabs(corr);
            if (abs_corr > max_abs) max_abs = abs_corr;
        }
        if (max_abs > 1e-12) found = 1;
        sum_max_abs += max_abs;
    }
    double avg_max_abs = sum_max_abs / 256.0;
    if (!found || avg_max_abs <= 1e-12) {
        *all_zero = 1;
        return 0.0;
    }
    *all_zero = 0;
    return log2(avg_max_abs);
}

/* ─────────────── Data structure for one input line ─────────────────────── */

typedef struct {
    char elem2[20];          /* hex string for mask h (or xi) */
    char elem3[20];          /* hex string for mask xi (or h) */
    double elem_value;       /* combined exponent from N₁·N₃ */
    uint8_t results1[4];     /* per‑byte masks derived from elem2 */
    uint8_t results2[4];     /* per‑byte masks derived from elem3 */
} LineData;

/* ──────────────────────────── Main program ─────────────────────────────── */

int main() {
    const char* filename = "0x5a80.txt";   /* input file with pre‑screened candidates */
    FILE* fp = fopen(filename, "r");
    if (!fp) {
        printf("Error: cannot open %s\n", filename);
        return 1;
    }
    char line[1024];
    LineData* lines = NULL;
    int line_count = 0;
    while (fgets(line, sizeof(line), fp)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (strlen(line) == 0) continue;
        char* parts[20];
        int part_count = 0;
        char copy[1024];
        strcpy(copy, line);
        char* tok = strtok(copy, " \t");
        while (tok && part_count < 20) {
            parts[part_count++] = tok;
            tok = strtok(NULL, " \t");
        }
        if (part_count < 5) continue;
        lines = (LineData*)realloc(lines, (line_count + 1) * sizeof(LineData));
        LineData* ld = &lines[line_count];
        if (part_count >= 7) {            // format with 8 fields: elem_value at position 6
            strcpy(ld->elem2, parts[2]);
            strcpy(ld->elem3, parts[3]);
            ld->elem_value = atof(parts[6]);
        } else {                          // format with 6 fields: elem_value at position 4
            strcpy(ld->elem2, parts[2]);
            strcpy(ld->elem3, parts[3]);
            ld->elem_value = atof(parts[4]);
        }
        uint32_t v1 = hex_string_to_uint(ld->elem2);
        uint32_t v2 = hex_string_to_uint(ld->elem3);
        allbox_optimized(v1, ld->results1);
        allbox_optimized(v2, ld->results2);
        line_count++;
    }
    fclose(fp);
    if (line_count == 0) {
        printf("No valid lines.\n");
        free(lines);
        return 0;
    }

    double best_value = -1e100;
    int best_line = -1;

    for (int idx = 0; idx < line_count; idx++) {
        LineData* ld = &lines[idx];
        double sum_exponents = 0.0;
        int valid_byte_pairs = 0;

        for (int p = 0; p < 4; p++) {
            uint8_t b1 = ld->results1[p];
            uint8_t b2 = ld->results2[p];
            int all_zero = 0;
            double exponent = compute_best_exponent_for_pair(b1, b2, &all_zero);
            if (!all_zero) {
                sum_exponents += exponent;
                valid_byte_pairs++;
            }
        }

        double final_value = sum_exponents + ld->elem_value;
        if (final_value > best_value) {
            best_value = final_value;
            best_line = idx + 1;      // 1‑based line number for report
        }
    }

    if (best_line != -1)
        printf("Best line: %d, value: %.12f\n", best_line, best_value);
    else
        printf("No valid byte pairs in any line.\n");

    free(lines);
    return 0;
}