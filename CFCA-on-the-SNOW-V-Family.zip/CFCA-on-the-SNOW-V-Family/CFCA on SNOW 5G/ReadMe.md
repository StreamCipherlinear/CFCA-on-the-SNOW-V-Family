Mask Search Workflow for SNOW 5G

=================================



This document describes the step-by-step procedure used to search for

high-correlation linear masks for SNOW 5G in the conditional fast

correlation attack. Each step relies on dedicated C/C++ programs and

produces intermediate files that are consumed by the subsequent steps.



\--------------------------------------------------------------------

Step 1 – Selection of the output mask gamma

\--------------------------------------------------------------------

Input:

&#x20; - Correlation computation for the N3.cpp

&#x20; - 255 nonzero values of gamma.txt



Procedure:

&#x20; Execute the program to evaluate the upper bound on cor(P3) for every

&#x20; candidate gamma. The script enumerates the active-byte space and

&#x20; records the corresponding correlations.



Output:

&#x20; - Candidates of gamma by cor(P3).txt

&#x20; - Candidates of gamma by cor(P3).xlsx

&#x20; The candidates are sorted by the value of cor(P3).



\--------------------------------------------------------------------

Step 2 – Evaluation of cor(N1)

\--------------------------------------------------------------------

Input:

&#x20; - Correlation computation for the N1.cpp



Procedure:

&#x20; The program exhaustively computes the correlation cor(N1) for all

&#x20; non-zero values of beta and m. A lookup table is built for efficient

&#x20; later use.



Output:

&#x20; A list of tuples (beta, m, log2|cor(N1)|), stored in an appropriate

&#x20; file (e.g., c(N1).txt).



\--------------------------------------------------------------------

Step 3 – Screening of the upper and lower block masks

\--------------------------------------------------------------------

Input:

&#x20; - Candidates of (n^H, xi^H, h^H) by cor(N3^H).cpp

&#x20; - Candidates of (n^L, xi^L, h^L, beta, m) by cor(N1)cor(N3^L).cpp



Procedure:

&#x20; The two programs search over the candidate sets of n, xi, h (together

&#x20; with beta, m for the lower block) and compute cor(N3^H) and

&#x20; cor(N1)\*cor(N3^L), respectively. Only combinations whose correlation

&#x20; exceeds a predefined threshold are kept.



Output:

&#x20; - 0x81ec.txt  – candidate masks for the upper block

&#x20; - 0x5a80.txt  – candidate masks for the lower block



\--------------------------------------------------------------------

Step 4 – Optimization of alpha and l for classical and conditional N2

\--------------------------------------------------------------------

Input:

&#x20; - 0x81ec.txt and 0x5a80.txt (from Step 3)

&#x20; - Classical\_candidates of (alpha, l).cpp

&#x20; - Computation of conditional correlation.cpp



Procedure:

&#x20; 1. Classical correlation:

&#x20;    For each surviving tuple (h, xi), the program

&#x20;    Classical\_candidates of (alpha, l).cpp exhaustively searches all

&#x20;    non-zero byte pairs (alpha, l) to maximise the contribution of N2.

&#x20;    The overall classical correlation is then obtained by combining the

&#x20;    best sub-approximations.



&#x20; 2. Conditional correlation:

&#x20;    The program Computation of conditional correlation.cpp evaluates the

&#x20;    conditional correlation cor\_con(N2) by, for every possible keystream

&#x20;    output value z^{(t-1)}, selecting the optimal mask l\_z and computing

&#x20;    the average maximum absolute correlation.



Output:

&#x20; The best linear masks (including alpha, l and all previously determined

&#x20; masks) together with their correlation exponents. These values are used

&#x20; to mount the final fast correlation attack on SNOW 5G.



\--------------------------------------------------------------------

All programs and data files are available in the repository. Please refer

to the comments inside each source file for implementation details and

parameter settings.

