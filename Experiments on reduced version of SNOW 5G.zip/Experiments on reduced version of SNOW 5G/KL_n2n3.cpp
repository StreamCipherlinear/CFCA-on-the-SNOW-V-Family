#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
#include <omp.h>

// ==================== GF(2^4) and Small AES S-box ====================
static uint8_t gf4_mul(uint8_t a, uint8_t b) {
    uint8_t p = 0;
    while (b) { if (b & 1) p ^= a; a <<= 1; if (a & 0x10) a ^= 0x13; b >>= 1; }
    return p & 0xF;
}
static const uint8_t SBOX[16] = {
    0x9, 0x4, 0xA, 0xB, 0xD, 0x1, 0x8, 0x5,
    0x6, 0x2, 0x0, 0x3, 0xC, 0xE, 0xF, 0x7
};

static inline uint8_t sr(uint8_t x) { return SBOX[x & 0xF]; }

static uint8_t S8_transform(uint8_t x) {
    uint8_t x0 = x & 0xF, x1 = (x >> 4) & 0xF;
    uint8_t y0 = sr(x0), y1 = sr(x1);
    uint8_t z0 = y0 ^ gf4_mul(4, y1);
    uint8_t z1 = gf4_mul(4, y0) ^ y1;
    return (z0 & 0xF) | ((z1 & 0xF) << 4);
}

// ==================== N2 and N3 formulas ====================
static inline uint8_t compute_N2(uint8_t invR2, uint8_t invR3, uint8_t R2, uint8_t R3, uint8_t T1_prev,
                                 uint8_t alpha4, uint8_t l8, uint8_t xi8, uint8_t h8) {
    uint8_t add = (invR2 + T1_prev) & 0xFF;
    int p1 = __builtin_parity((unsigned int)(alpha4 & add));
    int p2 = __builtin_parity((unsigned int)(l8 & T1_prev));
    int p3 = __builtin_parity((unsigned int)(xi8 & R2));
    int p4 = __builtin_parity((unsigned int)(alpha4 & invR3));
    int p5 = __builtin_parity((unsigned int)(h8 & R3));
    return (p1 ^ p2 ^ p3 ^ p4 ^ p5) & 0x1;
}

static inline uint8_t compute_N3(uint8_t R2, uint8_t R3, uint8_t T2, uint8_t T1_next,
                                 uint8_t gamma8, uint8_t n8, uint8_t beta4, uint8_t xi8, uint8_t h8) {
    uint8_t inner = R3 ^ T2;
    uint8_t xored = (inner + R2)  & 0xFF;
    uint8_t s_out = (xored + T1_next) & 0xFF;
    int p1 = __builtin_parity((unsigned int)(gamma8 & s_out));
    int p2 = __builtin_parity((unsigned int)(n8 & T1_next));
    int p3 = __builtin_parity((unsigned int)((beta4 ^ xi8) & R2));
    int p4 = __builtin_parity((unsigned int)(h8 & (R3 ^ T2)));
    return (p1 ^ p2 ^ p3 ^ p4) & 0x1;
}

// ==================== Main evaluation (paper method) with OpenMP parallelization ====================
void evaluate_independence_like_paper(uint8_t alpha4, uint8_t beta4, uint8_t gamma8,
                                      uint8_t xi8, uint8_t l8, uint8_t n8, uint8_t h8) {
    // Use separate reduction variables for each joint cell (allows OpenMP reduction)
    uint64_t j00 = 0, j01 = 0, j10 = 0, j11 = 0;

    // Enumerate all (R2,R3) with OpenMP parallel for
    #pragma omp parallel for reduction(+:j00, j01, j10, j11) schedule(dynamic)
    for (uint32_t rr = 0; rr < 65536; rr++) {
        uint8_t invR2 = rr & 0xFF;
        uint8_t invR3 = (rr >> 8) & 0xFF;
        uint8_t R2 = S8_transform(invR2);
        uint8_t R3 = S8_transform(invR3);

        // Distribution of N2 over T1_prev (256 values)
        uint64_t cnt2[2] = {0, 0};
        for (uint32_t t = 0; t < 256; t++) {
            uint8_t T1_prev = (uint8_t)t;
            uint8_t n2 = compute_N2(invR2, invR3, R2, R3, T1_prev, alpha4, l8, xi8, h8);
            cnt2[n2]++;
        }

        // Distribution of N3 over (T1_next, T2) (65536 values)
        uint64_t cnt3[2] = {0, 0};
        for (uint32_t tt = 0; tt < 65536; tt++) {
            uint8_t T1_next = (uint8_t)(tt & 0xFF);
            uint8_t T2 = (uint8_t)((tt >> 8) & 0xFF);
            uint8_t n3 = compute_N3(R2, R3, T2, T1_next, gamma8, n8, beta4, xi8, h8);
            cnt3[n3]++;
        }

        // Accumulate joint counts (local updates, reduced later)
        j00 += cnt2[0] * cnt3[0];
        j01 += cnt2[0] * cnt3[1];
        j10 += cnt2[1] * cnt3[0];
        j11 += cnt2[1] * cnt3[1];
    }

    // Build joint matrix
    uint64_t joint[2][2] = {{j00, j01}, {j10, j11}};

    // Normalize to probabilities
    double total = (double)(j00 + j01 + j10 + j11);
    double P[2][2];
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            P[i][j] = (double)joint[i][j] / total;

    // Marginals
    double P2[2] = {P[0][0] + P[0][1], P[1][0] + P[1][1]};
    double P3[2] = {P[0][0] + P[1][0], P[0][1] + P[1][1]};

    // Relative entropy (Kullback–Leibler divergence)
    double D_KL = 0.0;
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            double indep = P2[i] * P3[j];
            if (P[i][j] > 0 && indep > 0) {
                D_KL += P[i][j] * log2(P[i][j] / indep);
            }
        }
    }

    // Correlation difference Delta (auxiliary)
    double cor_N2 = P2[0] - P2[1];
    double cor_N3 = P3[0] - P3[1];
    double cor_joint = (P[0][0] + P[1][1]) - (P[0][1] + P[1][0]);
    double Delta = fabs(cor_joint - cor_N2 * cor_N3);

    // Output
    printf("========== Independence Test (Following SNOW-V Paper Method) ==========\n");
    printf("Masks: alpha=0x%X, beta=0x%X, gamma=0x%02X, xi=0x%02X, l=0x%02X, n=0x%02X, h=0x%02X\n",
           alpha4, beta4, gamma8, xi8, l8, n8, h8);
    printf("Joint Distribution P(N2,N3):\n");
    printf("  P(0,0)=%.8f, P(0,1)=%.8f\n", P[0][0], P[0][1]);
    printf("  P(1,0)=%.8f, P(1,1)=%.8f\n", P[1][0], P[1][1]);
    printf("Marginals: P(N2=0)=%.8f, P(N3=0)=%.8f\n", P2[0], P3[0]);
    printf("Correlations: cor(N2)=%.8f, cor(N3)=%.8f, cor(N2+N3)=%.8f\n", cor_N2, cor_N3, cor_joint);
    printf("\n>>> **Relative Entropy (K-L Divergence) D_KL = %.8f bits**\n", D_KL);
    printf(">>> **Correlation Product Error Delta = %.8f**\n", Delta);

    // Criterion from paper: D_KL < 0.01 indicates independence
    if (D_KL < 0.01) {
        printf("\n D_KL < 0.01, N2 and N3 can be treated as INDEPENDENT.\n");
        printf("   (Consistent with the scaled experiment conclusion in the SNOW-V paper.)\n");
    } else {
        printf("\n D_KL is NOT negligible. Independence assumption FAILS.\n");
    }
}

// ==================== Main ====================
int main(void) {
    uint8_t alpha4 = 0xc;
    uint8_t beta4  = 0x8;
    uint8_t gamma8 = 0x41;
    uint8_t xi8    = 0x69;
    uint8_t l8     = 0x8;
    uint8_t n8     = 0x61;
    uint8_t h8     = 0x41;

    evaluate_independence_like_paper(alpha4, beta4, gamma8, xi8, l8, n8, h8);
    return 0;
}