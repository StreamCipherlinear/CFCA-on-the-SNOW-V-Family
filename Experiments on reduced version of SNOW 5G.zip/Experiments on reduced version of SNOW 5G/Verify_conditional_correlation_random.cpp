#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

// ---------- finite field operations ----------
static inline uint8_t gf16_mul(uint8_t a, uint8_t b) {
    uint8_t p = 0;
    for (int i = 0; i < 4; i++) {
        if (b & 1) p ^= a;
        a <<= 1;
        if (a & 0x10) a ^= 0x13;
        b >>= 1;
    }
    return p & 0xF;
}

// ---------- S-box and transforms ----------
static const uint8_t SBOX[16] = {
    0x9, 0x4, 0xA, 0xB, 0xD, 0x1, 0x8, 0x5,
    0x6, 0x2, 0x0, 0x3, 0xC, 0xE, 0xF, 0x7
};

static inline uint8_t sr(uint8_t x) {
    return SBOX[x & 0xF];
}

static uint8_t S8_transform(uint8_t x) {
    uint8_t x0 = x & 0xF, x1 = (x >> 4) & 0xF;
    uint8_t y0 = sr(x0), y1 = sr(x1);
    uint8_t z0 = y0 ^ gf16_mul(4, y1);
    uint8_t z1 = gf16_mul(4, y0) ^ y1;
    return (z0 & 0xF) | ((z1 & 0xF) << 4);
}

static inline uint16_t S16_transform(uint16_t x) {
    uint8_t hi = S8_transform((x >> 8) & 0xFF);
    uint8_t lo = S8_transform(x & 0xFF);
    return ((uint16_t)hi << 8) | lo;
}

// ---------- linear mask dot product ----------
static inline int dot16(uint16_t a, uint16_t b) {
    return __builtin_parity((unsigned int)(a & b));
}

// ---------- adaptive table for linear hull ----------
void compute_adaptive_table(uint16_t xi, uint16_t h,
                            uint16_t best_l[16], int tau[16]) {
    for (int u = 0; u < 16; u++) {
        double best_abs = 0.0;
        uint16_t best_l_u = 0;
        int best_tau = 0;
        for (uint16_t l = 0; l < 256; l++) {      // mask low byte only
            int s = 0;
            for (int x = 0; x < 256; x++) {
                for (int y = 0; y < 256; y++) {
                    int z = u ^ ((x + y) & 0xFF);
                    uint16_t X = S16_transform(x);
                    uint16_t Z = S16_transform(z);
                    if ((dot16(xi, X) ^ dot16(l, y) ^ dot16(h, Z)) == 0)
                        s++;
                    else
                        s--;
                }
            }
            double cor = s / 65536.0;
            if (fabs(cor) > best_abs) {
                best_abs = fabs(cor);
                best_l_u = l;
                best_tau = (cor >= 0) ? 1 : 0;
            }
        }
        best_l[u] = best_l_u;
        tau[u] = best_tau;
    }
}

// ---------- 16-bit random number generator ----------
static inline uint16_t rand16(void) {
    return (rand() & 0xFFFF);   // assumes RAND_MAX >= 65535 or uses low bits
}

// ---------- main experiment ----------
int main(void) {
    // fixed attack masks (high bytes are zero)
    uint16_t beta  = 0x0008;
    uint16_t gamma = 0x0041;
    uint16_t m     = 0x0008;
    uint16_t n     = 0x0061;
    uint16_t h     = 0x0041;
    uint16_t xi    = 0x0069;

    // compute adaptive table
    uint16_t best_l[16];
    int tau[16];
    compute_adaptive_table(xi, h, best_l, tau);

    printf("Adaptive table (u -> best_l, tau):\n");
    for (int u = 0; u < 16; u++)
        printf(" u=0x%X: l=0x%04X, tau=%d\n", u, best_l[u], tau[u]);
    printf("\n");

    const int N = 1 << 20;       // number of independent trials
    int cnt0 = 0;
    srand(time(NULL));

    for (int i = 0; i < N; i++) {
        // --- random previous state and keystream at time t-1 ---
        uint16_t R1_prev = rand16();
        uint16_t R2_prev = rand16();
        uint16_t R3_prev = rand16();
        uint16_t T1_prev = rand16();
        uint16_t T2_prev = rand16();
        uint16_t z_prev  = (R1_prev + T1_prev) ^ R2_prev;

        // --- random T1, T2 at current time t ---
        uint16_t T1_cur = rand16();
        uint16_t T2_cur = rand16();

        // FSM update to obtain state at time t
        uint16_t R1_cur = R2_prev + (R3_prev ^ T2_prev);
        uint16_t R2_cur = S16_transform(R1_prev);
        uint16_t R3_cur = S16_transform(R2_prev);
        uint16_t z_cur  = (R1_cur + T1_cur) ^ R2_cur;

        // --- random T1 at time t+1 ---
        uint16_t T1_next = rand16();

        // update to t+1
        uint16_t R1_next = R2_cur + (R3_cur ^ T2_cur);
        uint16_t R2_next = S16_transform(R1_cur);
        uint16_t z_next  = (R1_next + T1_next) ^ R2_next;

        // --- evaluate linear equation ---
        uint8_t u = z_prev & 0xF;
        uint16_t l_adapt = best_l[u];
        int tau_adapt = tau[u];

        int eq = dot16(beta, z_cur) ^ dot16(gamma, z_next)
               ^ dot16(l_adapt, T1_prev) ^ dot16(m, T1_cur)
               ^ dot16(n, T1_next) ^ dot16(h, T2_cur) ^ tau_adapt;

        if (eq == 0) cnt0++;
    }

    double cor = (2.0 * cnt0 - N) / (double)N;
    printf("===== Random independent experiment (N = %d) =====\n", N);
    printf("Measured correlation = %+.6f\n", cor);

    // theoretical reference (computed under independence assumptions)
    double avg_abs_cor_u = 0.148438;
    double cor_N1N3_abs  = pow(2.0, -3.586);
    double theory_cond   = avg_abs_cor_u * cor_N1N3_abs;
    printf("Theoretical conditional cor (old) = %.6f\n", theory_cond);

    double P0_actual = (1.0 + cor) / 2.0;
    double P1_actual = 1.0 - P0_actual;
    double P0_theory = (1.0 + theory_cond) / 2.0;
    double P1_theory = 1.0 - P0_theory;
    double kl_theory = P0_actual * log2(P0_actual / P0_theory)
                     + P1_actual * log2(P1_actual / P1_theory);
    double kl_uniform = P0_actual * log2(P0_actual / 0.5)
                      + P1_actual * log2(P1_actual / 0.5);
    printf("KL(actual || theory)  = %.6f bits\n", kl_theory);
    printf("KL(actual || uniform) = %.6f bits\n", kl_uniform);
    printf("Theory is %s than random guess.\n",
           kl_theory < kl_uniform ? "better" : "worse");

    return 0;
}