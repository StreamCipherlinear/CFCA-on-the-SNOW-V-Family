#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

/* ---------- GF(16) arithmetic ---------- */
static inline uint8_t gf16_mul(uint8_t a, uint8_t b) {
    uint8_t p = 0;
    for (int i = 0; i < 4; i++) {
        if (b & 1) p ^= a;
        a <<= 1;
        if (a & 0x10) a ^= 0x13;
        b >>= 1;
    }
    return p & 0xF;
}

/* ---------- S‑box (4‑bit) ---------- */
static const uint8_t SBOX[16] = {
    0x9, 0x4, 0xA, 0xB, 0xD, 0x1, 0x8, 0x5,
    0x6, 0x2, 0x0, 0x3, 0xC, 0xE, 0xF, 0x7
};

static inline uint8_t sr(uint8_t x) {
    return SBOX[x & 0xF];
}

static uint8_t S8_transform(uint8_t x) {
    uint8_t x0 = x & 0xF, x1 = (x >> 4) & 0xF;
    uint8_t y0 = sr(x0), y1 = sr(x1);
    uint8_t z0 = y0 ^ gf16_mul(4, y1);
    uint8_t z1 = gf16_mul(4, y0) ^ y1;
    return (z0 & 0xF) | ((z1 & 0xF) << 4);
}

static inline uint16_t S16_transform(uint16_t x) {
    uint8_t hi = S8_transform((x >> 8) & 0xFF);
    uint8_t lo = S8_transform(x & 0xFF);
    return ((uint16_t)hi << 8) | lo;
}

/* ---------- Linear mask dot product ---------- */
static inline int dot16(uint16_t a, uint16_t b) {
    return __builtin_parity((unsigned int)(a & b));
}

/* ---------- Adaptive table ---------- */
/*
 * For each 4‑bit index u, finds the best mask l and sign tau
 * that maximize the absolute correlation of
 *   xi·X ^ l·y ^ h·Z
 * where X = S16(x), Z = S16(x ^ u), and y runs over all 8‑bit values.
 *
 * Also stores the maximum absolute correlation in best_cor_abs[u].
 */
void compute_adaptive_table(uint16_t xi, uint16_t h,
                            uint16_t best_l[16], int tau[16],
                            double best_cor_abs[16]) {
    for (int u = 0; u < 16; u++) {
        double best_abs = 0.0;
        uint16_t best_l_u = 0;
        int best_tau = 0;
        for (uint16_t l = 0; l < 256; l++) {
            int s = 0;
            for (int x = 0; x < 256; x++) {
                for (int y = 0; y < 256; y++) {
                    int z = u ^ ((x + y) & 0xFF);
                    uint16_t X = S16_transform(x);
                    uint16_t Z = S16_transform(z);
                    if ((dot16(xi, X) ^ dot16(l, y) ^ dot16(h, Z)) == 0)
                        s++;
                    else
                        s--;
                }
            }
            double cor = s / 65536.0;
            if (fabs(cor) > best_abs) {
                best_abs = fabs(cor);
                best_l_u = l;
                best_tau = (cor >= 0) ? 1 : 0;
            }
        }
        best_l[u] = best_l_u;
        tau[u] = best_tau;
        best_cor_abs[u] = best_abs;   // store the maximal absolute correlation
    }
}

/* ========== 64‑bit primitive LFSR ========== */
static inline uint64_t lfsr_shift(uint64_t state) {
    for (int i = 0; i < 16; i++) {
        uint64_t feedback = (state >> 63) & 1;
        state = (state << 1) | feedback;
        if (feedback)
            state ^= 0x1B;
    }
    return state;
}

static inline void extract_taps(uint64_t state, uint16_t *T1, uint16_t *T2) {
    *T2 = (uint16_t)(state & 0xFFFF);
    *T1 = (uint16_t)((state >> 32) & 0xFFFF);
}

/* ========== Main program ========== */
int main(void) {
    /* Linear masks */
    uint16_t beta  = 0x0008;
    uint16_t gamma = 0x0041;
    uint16_t m     = 0x0008;
    uint16_t n     = 0x0061;
    uint16_t h     = 0x0041;
    uint16_t xi    = 0x0069;

    /* Pre‑compute adaptive table: now also stores the conditional correlation */
    uint16_t best_l[16];
    int tau[16];
    double best_cor_abs[16];      
    compute_adaptive_table(xi, h, best_l, tau, best_cor_abs);

    printf("Adaptive table (u -> best_l, tau, |cor|):\n");
    for (int u = 0; u < 16; u++)
        printf(" u=0x%X: l=0x%04X, tau=%d, |cor|=%.6f\n",
               u, best_l[u], tau[u], best_cor_abs[u]);

    const int N = 1 << 20;   
    int cnt0 = 0;
    double sum_cond_cor = 0.0;   // NEW: accumulate conditional correlations

    /* ----- Initialisation ----- */
    srand(time(NULL));
    uint64_t lfsr_state = ((uint64_t)rand() << 32) ^ rand();
    if (lfsr_state == 0) lfsr_state = 1;

    uint16_t R1 = rand() & 0xFFFF;
    uint16_t R2 = rand() & 0xFFFF;
    uint16_t R3 = rand() & 0xFFFF;

    uint16_t *z  = (uint16_t*)malloc((N+2) * sizeof(uint16_t));
    uint16_t *T1 = (uint16_t*)malloc((N+2) * sizeof(uint16_t));
    uint16_t *T2 = (uint16_t*)malloc((N+2) * sizeof(uint16_t));
    if (!z || !T1 || !T2) return 1;

    /* ----- Generate keystream ----- */
    extract_taps(lfsr_state, &T1[0], &T2[0]);
    z[0] = (R1 + T1[0]) ^ R2;
    lfsr_state = lfsr_shift(lfsr_state);

    for (int t = 1; t <= N+1; t++) {
        extract_taps(lfsr_state, &T1[t], &T2[t]);

        uint16_t new_R1 = R2 + (R3 ^ T2[t-1]);
        uint16_t new_R2 = S16_transform(R1);
        uint16_t new_R3 = S16_transform(R2);
        R1 = new_R1; R2 = new_R2; R3 = new_R3;

        z[t] = (R1 + T1[t]) ^ R2;
        lfsr_state = lfsr_shift(lfsr_state);
    }

    /* ----- Attack window ----- */
    for (int t = 1; t <= N; t++) {
        uint8_t u = z[t-1] & 0xF;
        uint16_t l_adapt = best_l[u];
        int tau_adapt = tau[u];

        int eq = dot16(beta, z[t]) ^ dot16(gamma, z[t+1])
               ^ dot16(l_adapt, T1[t-1]) ^ dot16(m, T1[t])
               ^ dot16(n, T1[t+1]) ^ dot16(h, T2[t]) ^ tau_adapt;

        if (eq == 0) cnt0++;

        // Accumulate the conditional correlation for this u
        sum_cond_cor += best_cor_abs[u];
    }

    free(z); free(T1); free(T2);

    double cor_measured = (2.0 * cnt0 - N) / (double)N;
    double mean_cond_cor = sum_cond_cor / N;
    double theory_cor = 0.148438 * pow(2.0, -3.586);
    double measured_theory = mean_cond_cor * pow(2.0, -3.586);

    printf("\n===== Results (N = %d) =====\n", N);
    printf("Theoretical correlation = %+.6f\n", theory_cor);
    printf("Measured correlation    = %+.6f\n", cor_measured);
    printf("Measured theoretical    = %+.6f\n", measured_theory);

    return 0;
}