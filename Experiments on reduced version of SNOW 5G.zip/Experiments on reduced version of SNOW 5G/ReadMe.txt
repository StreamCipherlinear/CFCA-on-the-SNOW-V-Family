# Linear Cryptanalysis of Reduced SNOW 5G 

The codes in this file are all based on this reduced version. 

## Reduced Version Setting

We have experimentally validated our claims on a reduced SNOW 5G, using 16‑bit modular addition and the function *S* from [ZXM15] (Appendix D) with update/output functions identical to SNOW 5G. The linear cryptanalysis structure (approximation over three consecutive outputs, split into three parts) is exactly as in Section 4.1.

LFSR: 64‑bit, primitive polynomial f(x) =  x^64 +x^4 +x^3 +x+1 updates 16 times per step; taps T1 and T2 are taken from the 32–47 and bits low 16 bits.

Here we use `+` to represent 16‑bit modular addition. The FSM part includes three 16-bit registers R1, R2, R3, and takes T1, T2 from LFSR to produce one 16-bit keystream symbol and update the registers.

**Output Function:**  
`z^t = (R1^t + T1^t) ^ R2^t`

**Updating Function:**  
`R1^{t+1} = R2^t + (R3^t ^ T2^t)`  
`R2^{t+1} = S(R1^t)`  
`R3^{t+1} = S(R2^t)`

___________________________________________________________________________________________________________________________________________________________________________________________

## Linear Cryptanalysis of This Cipher

In the following, `*` denotes the inner (dot) product, and `^` denotes bitwise XOR.

Consider three consecutive keystream outputs:

alpha * z^{t-1} ^ beta * z^t ^ gamma * z^{t+1} = l * T1^{t-1} ^ m * T1^t ^ n * T1^{t+1} ^ h * T2^t


The case that yields high correlation is the one where alpha and beta each introduce exactly one 4‑bit active S‑box.

___________________________________________________________________________________________________________________________________________________________________________________________

## Code Listing

- **`cn1cn2.cpp` and `cn3.cpp`**  
  Compute the classical correlation.

- **`KL_n2n3.cpp`**  
  Verify the independence between the sub‑approximations N2 and N3.

- **`cor_con.cpp`**  
  Compute the theoretical conditional correlation.

- **`Verify_conditional_correlation_random`**  
  Check the consistency between theoretical and empirical conditional correlations when the taps T1, T2 and registers R1, R2, R3 are treated as random variables.

- **`Verify_conditional_correlation_true`**  
  Check the consistency between theoretical and empirical conditional correlations when the taps T1, T2 and registers R1, R2, R3 follow the stream cipher's distribution.

- **`Recover_initial_state`**
Recover the initial LFSR state of CFCA, supporting both direct (Case 1) and pair (Case 2) modes.

